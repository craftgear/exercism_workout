/********************************************************

  octreve.h : オクトリバーシ

              Copyright (C) 1999-2005,2014 Makoto Hiroi


  盤面の座標（１次元配列で表す）

  0  1  2  3  4  5  6  7
  -+-----------------------
  0| 0  1  2  3  4  5  6  7
  1| 8  9 10 11 12 13 14 15
  2|16 17 18 19 20 21 22 23
  3|24 25 26 27 28 29 30 31
  4|32 33 34 35 36 37 38 39
  5|40 41 42 43 44 45 46 47
  6|48 49 50 51 52 53 54 55
  7|56 57 58 59 60 61 62 63
  
*********************************************************/
#ifndef _OCTREV_H_
#define _OCTREV_H_

#include	<stdlib.h>
#include	<time.h>
#include	<limits.h>
#include	<string.h>

#define	TRUE	1
#define	FALSE	0

#define	SIZE	64		/* 盤面の大きさ */
#define P_SIZE  60              /* 石の総数 */
#define	BLACK	0		/* 黒石 */
#define	WHITE	1		/* 白石 */
#define	FREE	2		/* 駒なし */
#define WALL    4

#define	PASS	(-1)	/* パスした場合 */

#define	MAX_LEVEL	20	/* 探索最大手数 */

#define	MAX_VALUE	100000
#define	MIN_VALUE	(-100000)
#define	NO_VALUE	INT_MAX

#endif

/* end of file */
