/********************************************************

  octrev.c : オクトリバーシ思考ルーチン

             Copyright (C) 1999-2005,2014 Makoto Hiroi

コンパイル
gcc -O2 -shared -fPIC -ooctrev.so octrev.c data.c

*********************************************************/
#include <tcl/tcl.h>
#include <string.h>
#include "octrev.h"

/* 関数宣言 */
static int search_white( int, int, int );
static int finish_white( int, int );

extern char reverse_table[512][8];

/* 盤面をコピーせずに書き換える '99-10 */
static char  board[SIZE];
static short white;
static short black;

static int  depth;			/* 探索手数 */
static int  space[SIZE];                /* 探索領域（読み切り時に効果大！） */
static int  space_count;                /* 双方向リストは効果が無いようだ */
static int  value_table[SIZE];

static int w1;   			/* 位置数の重み */
static int w2;                          /* 石数の重み */

/* αβの限界値 */
#define MAX_LIMIT (MAX_VALUE + 100)
#define MIN_LIMIT (MIN_VALUE - 100)

/* 石を置けるか */
#define PUT_BLACK  1
#define PUT_WHITE  2

/* 初期化データ */
static const char init_table[SIZE] = {
  WALL, FREE, FREE, FREE,  FREE,  FREE, FREE, WALL,
  FREE, FREE, FREE, FREE,  FREE,  FREE, FREE, FREE,
  FREE, FREE, FREE, FREE,  FREE,  FREE, FREE, FREE,
  FREE, FREE, FREE, WHITE, BLACK, FREE, FREE, FREE,
  FREE, FREE, FREE, BLACK, WHITE, FREE, FREE, FREE,
  FREE, FREE, FREE, FREE,  FREE,  FREE, FREE, FREE,
  FREE, FREE, FREE, FREE,  FREE,  FREE, FREE, FREE,
  WALL, FREE, FREE, FREE,  FREE,  FREE, FREE, WALL,
};

/* データの初期化 */
static void init_data( void )
{
  int		i;
  const char	*ptr = init_table;
  for( i = 0; i < SIZE; i++, ptr++ ){
    board[i] = *ptr;
  }
  white = 2;
  black = 2;
}

/* 駒を置ける場所をセットする */
static int set_space_postion( void )
{
  int i, c;
  for( i = c = 0; i < SIZE; i++ ){
    if( board[i] == FREE ){
      space[c] = i;
      value_table[c++] = NO_VALUE;
    }
  }
  return space_count = c;
}

/* 駒を裏返すことができるか */
static int check_reverse( int num, int piece )
{
  int	i;
  /* 8 方向をチェックする */
  for( i = 0; i < 8; i++ ){
    int	 c = 0, flag = FALSE;
    char *ptr = reverse_table[num * 8 + i];
    if( *ptr == -1 ) break;	/* 終了 */
    do {
      int content = board[*ptr];
      if( content == FREE ){
	break;			/* 空きエリア */
      } else if( content == piece ){
	flag = TRUE; break;	/* 同種の駒 */
      } else {
	c++;
      }
    } while( *(++ptr) != -1 );
    if( flag && c ) return TRUE;
  }
  return FALSE;
}

/* 駒を反転する */
static int reverse_piece( int num, int piece, char *result )
{
  int	i, count = 0;
  if( board[num] != FREE ) return 0; /* 石を置くことはできないよ */
  /* 8 方向をチェックする */
  for( i = 0; i < 8; i++ ){
    int  c = count, flag = FALSE;
    char *ptr = &(reverse_table[num * 8 + i][0]);
    if( *ptr == -1 ) break;
    do {
      int content = board[*ptr];
      if( content == FREE ){
	break;			/* 空きエリア */
      } else if( content == piece ){
	flag = TRUE; break;	/* 同種の駒を見つけたよ */
      } else {
	result[c++] = *ptr;	/* 異種の駒 */
      }
    } while( *(++ptr) != -1 );

    if( flag && (c > count) ){
      count = c;		/* 裏返しができたよ */
    }
  }
  result[count] = -1;           /* 終端セット */
  if( count ){			/* 駒を置くことができるよ */
    board[num] = piece;
    for( i = 0; i < count; i++ ){
      board[ result[i] ] = piece;
    }
    if( piece == BLACK ){
      black += count + 1;
      white -= count;
    } else {
      white += count + 1;
      black -= count;
    }
  }
  return count;
}

/* 駒を置くことができる場所を数える */
static int count_postion( int piece )
{
  int	i, count = 0;
  for( i = 0; i < SIZE; i++ ){
    if( board[i] != FREE ) continue;
    if( check_reverse( i, piece ) ) count++;
  }
  return count;
}

/* 石を置くことができるか */
static void put_piece_map( char *map )
{
  /* データ */
  static short scan_table[8][12] = {
     0,  8, 16, 24, 32, 40, 48, 56, -1, -1, -1, -1,   /* 左から右へ */
     0,  1,  2,  3,  4,  5,  6,  7, -1, -1, -1, -1,   /* 上から下へ */
     7, 15, 23, 31, 39, 47, 55, 63, -1, -1, -1, -1,   /* 右から左へ */
    56, 57, 58, 59, 60, 61, 62, 63, -1, -1, -1, -1,   /* 下から上へ */
     2,  3,  4,  5,  6,  7, 15, 23, 31, 39, 47, -1,   /* 上から左下へ */
     5,  4,  3,  2,  1,  0,  8, 16, 24, 32, 40, -1,   /* 上から右下へ */
    58, 59, 60, 61, 62, 63, 55, 47, 39, 31, 33, -1,   /* 下から左上へ */
    61, 60, 59, 58, 57, 56, 48, 40, 32, 24, 16, -1,   /* 下から右上へ */
   };
  static short scan_count[8][12] = {
    8, 8, 8, 8, 8, 8, 8, 8, -1, -1, -1, -1,
    8, 8, 8, 8, 8, 8, 8, 8, -1, -1, -1, -1,
    8, 8, 8, 8, 8, 8, 8, 8, -1, -1, -1, -1,
    8, 8, 8, 8, 8, 8, 8, 8, -1, -1, -1, -1,
    3, 4, 5, 6, 7, 8, 7, 6,  5,  4,  3, -1,
    3, 4, 5, 6, 7, 8, 7, 6,  5,  4,  3, -1,
    3, 4, 5, 6, 7, 8, 7, 6,  5,  4,  3, -1,
    3, 4, 5, 6, 7, 8, 7, 6,  5,  4,  3, -1,
  };
  static short scan_vector[8] = {
    1, 8, -1, -8, 7, 9, -9, -7,
  };

  int i;
  memset( map, 0, SIZE );
  for( i = 0; i < 8; i++ ){
    short dp = scan_vector[i];
    short j, pos;
    for( j = 0; (pos = scan_table[i][j]) != -1; j++ ){
      short count = scan_count[i][j];
      short space_postion = -1;
      char  piece = FREE;
      while( count > 0 ){
	if( board[pos] == FREE ){
	  space_postion = pos;
	  piece = FREE;
	} else if( space_postion > 0 ){
	  if( piece == FREE ){
	    piece = board[pos];
	  } else if( piece != board[pos] ){
	    map[space_postion] |= (piece == WHITE ? PUT_BLACK : PUT_WHITE);
	    space_postion = -1;
	    piece = FREE;
	  }
	}
	count--;
	pos += dp;
      }
    }
  }
}

/* 重みテーブル */
static const int weight_table[SIZE] = {
     0, 1000, 10, 20, 20, 10, 1000, 0,
  1000,    0,  1,  1,  1,  1,    0, 1000,
    10,    1,  1,  1,  1,  1,    1,   10,
    20,    1,  1,  1,  1,  1,    1,   20,
    20,    1,  1,  1,  1,  1,    1,   20,
    10,    1,  1,  1,  1,  1,    1,   10,
  1000,    0,  1,  1,  1,  1,    0, 1000,
     0, 1000, 10, 20, 20, 10, 1000, 0,
};

/* 評価関数（黒有利が正となる） */
static int value_func( int turn )
{
  int	bv = 0, wv = 0, bc = 0, wc = 0, i;
  char map[SIZE];
  put_piece_map( map );
  for( i = 1; i < SIZE - 1; i++ ){
    switch( board[i] ){
    case BLACK:
      bv += weight_table[i]; break;
    case WHITE:
      wv += weight_table[i]; break;
    case FREE:
      if( weight_table[i] ){
	if( map[i] & PUT_BLACK ) bc++;
	if( map[i] & PUT_WHITE ) wc++;
      }
      break;
    }
  }
  return (bc - wc) * w1 + bv - wv + (white - black) * w2;
}

/* 結果判定 */
static int result_value( int flag )
{
  int	value;
  int	wc = white;
  int	bc = black;
  if( wc + bc == P_SIZE || flag == TRUE ){
    if( wc == bc ){
      value = 0;		/* 引き分け */
    } else if( bc > wc ){
      value = MAX_VALUE + bc - wc; /* 黒勝ち */
    } else {
      value = MIN_VALUE + bc - wc; /* 白勝ち */
    }
  } else if( wc == 0 ){
    value = MAX_VALUE + bc;	/* 白全滅 */
  } else if( bc == 0 ){
    value = MIN_VALUE - wc;	/* 黒全滅 */
  } else {
    value = NO_VALUE;		/* 決着がついていないよ */
  }
  return value;
}


/* ミニマックスによる探索 */
static int search_black( int his, int limit, int pass_flag )
{
  int i, point = MIN_LIMIT;
  short save_white = white;
  short save_black = black;
  if( his == depth ){
    return value_func( BLACK );
  }
  for( i = 0; i < space_count; i++ ){
    int value, pos = space[i];
    char piece_buffer[SIZE/2];

    /* 駒が置いてあるかチェックする */
    if( board[pos] != FREE ) continue;
    /* 駒を置く */
    if( !reverse_piece( pos, BLACK, piece_buffer ) ) continue;

    /* 終了チェック */
    if( (value = result_value( FALSE )) == NO_VALUE ){
      /* 相手の手番 */
      value = search_white( his + 1, point, FALSE );
    }
    /* 駒を元に戻す */
    {
      char *ptr = piece_buffer;
      board[pos] = FREE;
      white = save_white;
      black = save_black;
      do {
	board[*ptr++] = WHITE;
      } while( *ptr != -1 );
    }
    /* ミニマックス */
    if( value > point ){
      point = value;
    }
    /* αβ枝刈 */
    if( point > limit ){
      break;
    }
  }
  if( point == MIN_LIMIT ){
    /* 打つ手がなかった */
    if( pass_flag == TRUE ){
      /* 相手も打つ手なし */
      point = result_value( TRUE ); /* 終了 */
    } else {
      /* パスだよ */
      point = search_white( his, MIN_LIMIT, TRUE );
    }
  }
  return point;
}

/* 白番 */
static int search_white( int his, int limit, int pass_flag )
{
  int   i, point = MAX_LIMIT;
  short save_white = white;
  short save_black = black;
  if( his == depth ){
    return value_func( WHITE );
  }
  for( i = 0; i < space_count; i++ ){
    int value, pos = space[i];
    char piece_buffer[SIZE/2];

    /* 駒が置いてあるかチェックする */
    if( board[pos] != FREE ) continue;
    /* 駒を置く */
    if( !reverse_piece( pos, WHITE, piece_buffer ) ) continue;

    /* 終了チェック */
    if( (value = result_value( FALSE )) == NO_VALUE ){
      /* 再帰する */
      value = search_black( his + 1, point, FALSE );
    }
    /* 駒を元に戻す */
    {
      char *ptr = piece_buffer;
      board[pos] = FREE;
      white = save_white;
      black = save_black;
      do {
	board[*ptr++] = BLACK;
      } while( *ptr != -1 );
    }

    /* ミニマックス */
    if( point > value ){
      point = value;
    }
    /* αβ枝刈 */
    if( point < limit ){
      break;
    }
  }
  if( point == MAX_LIMIT ){
    /* 打つ手がなかった */
    if( pass_flag == TRUE ){
      /* 相手も打つ手なし */
      point = result_value( TRUE ); /* 終了 */
    } else {
      /* パスだよ */
      point = search_black( his, MAX_LIMIT, TRUE );
    }
  }
  return point;
}

/* 読み切り専用 */
static int finish_black( int limit, int pass_flag )
{
  int i, point = MIN_LIMIT;
  short save_white = white;
  short save_black = black;
  for( i = 0; i < space_count; i++ ){
    int value, pos = space[i];
    char piece_buffer[SIZE/2];

    /* 駒が置いてあるかチェックする */
    if( board[pos] != FREE ) continue;
    /* 駒を置く */
    if( !reverse_piece( pos, BLACK, piece_buffer ) ) continue;

    /* 終了チェック */
    if( black + white < P_SIZE ){
      value = finish_white( point, FALSE );
    } else {
      value = black - white;
    }
    /* 駒を元に戻す */
    {
      char *ptr = piece_buffer;
      board[pos] = FREE;
      white = save_white;
      black = save_black;
      do {
	board[*ptr++] = WHITE;
      } while( *ptr != -1 );
    }
    /* ミニマックス */
    if( value > point ){
      point = value;
    }
    /* αβ枝刈 */
    if( point > limit ){
      break;
    }
  }
  if( point == MIN_LIMIT ){
    /* 打つ手がなかった */
    if( pass_flag == TRUE ){
      /* 相手も打つ手なし */
      point = black - white; /* 終了 */
    } else {
      /* パスだよ */
      point = finish_white( MIN_LIMIT, TRUE );
    }
  }
  return point;
}

/* 白番 */
static int finish_white( int limit, int pass_flag )
{
  int   i, point = MAX_LIMIT;
  short save_white = white;
  short save_black = black;
  for( i = 0; i < space_count; i++ ){
    int value, pos = space[i];
    char piece_buffer[SIZE];

    /* 駒が置いてあるかチェックする */
    if( board[pos] != FREE ) continue;
    /* 駒を置く */
    if( !reverse_piece( pos, WHITE, piece_buffer ) ) continue;

    /* 終了チェック */
    if( black + white < P_SIZE ){
      value = finish_black( point, FALSE );
    } else {
      value = black - white;
    }
    /* 駒を元に戻す */
    {
      char *ptr = piece_buffer;
      board[pos] = FREE;
      white = save_white;
      black = save_black;
      do {
	board[*ptr++] = BLACK;
      } while( *ptr != -1 );
    }

    /* ミニマックス */
    if( point > value ){
      point = value;
    }
    /* αβ枝刈 */
    if( point < limit ){
      break;
    }
  }
  if( point == MAX_LIMIT ){
    /* 打つ手がなかった */
    if( pass_flag == TRUE ){
      /* 相手も打つ手なし */
      point = black - white;
    } else {
      /* パスだよ */
      point = finish_black( MAX_LIMIT, TRUE );
    }
  }
  return point;
}

/* 単純挿入ソート */
static void sort( int limit )
{
  int i, j;
  for( i = 1; i < limit; i++ ){
    int tmp_pos = space[i];
    int tmp_value = value_table[i];
    for( j = i - 1; j >= 0 && tmp_value > value_table[j]; j-- ){
      space[j + 1] = space[j];
      value_table[j + 1] = value_table[j];
    }
    space[j + 1] = tmp_pos;
    value_table[j + 1] = tmp_value;
  }
}

static void rsort( int limit )
{
  int i, j;
  for( i = 1; i < limit; i++ ){
    int tmp_pos = space[i];
    int tmp_value = value_table[i];
    for( j = i - 1; j >= 0 && tmp_value < value_table[j]; j-- ){
      space[j + 1] = space[j];
      value_table[j + 1] = value_table[j];
    }
    space[j + 1] = tmp_pos;
    value_table[j + 1] = tmp_value;
  }
}

/* 反復深化による探索 */
static void search_move( int turn, int level )
{
  int limit = set_space_postion();
  int flag = FALSE;
  short save_white = white;
  short save_black = black;
  /* 先読み手数セット 1 -> 3 -> 5, 2 -> 4 -> 6 と反復させる */
  depth = (level & 0x01) ? 1 : 2;
  for( ; depth <= level; depth += 2 ){
    int i, point = (turn == BLACK ? MIN_LIMIT : MAX_LIMIT);
    for( i = 0; i < limit; i++ ){
      int value, pos = space[i];
      char piece_buffer[SIZE/2];
      if( board[pos] != FREE ) continue;

      /* 石を置く */
      if( !reverse_piece( pos, turn, piece_buffer ) ) continue;
      /* 終了チェック */
      if( (value = result_value( FALSE )) == NO_VALUE ){
	if( turn == BLACK ){
	  value = search_white( 1, point, FALSE );
	} else {
	  value = search_black( 1, point, FALSE );
	}
      }
      value_table[i] = value;
      /* 元に戻す */
      {
	char *ptr = piece_buffer;
	char piece = (turn == BLACK ? WHITE : BLACK);
	white = save_white;
	black = save_black;
	board[pos] = FREE;
	do {
	  board[*ptr++] = piece;
	} while( *ptr != -1 );
      }
      if((turn == BLACK && value > point) ||
	 (turn == WHITE && value < point) ){
	point = value;
      }
    }
    if( depth <= 2 ){
      /* NO_VALUE を後ろに集める */
      rsort( limit );
      /* NO_VALUE を除外する */
      while( value_table[limit - 1] == NO_VALUE ) limit--;
    }
    if( turn == BLACK ) sort( limit ); else rsort( limit );
  }
}

/* 読み切り */
static void finish_move( int turn )
{
  int   limit = set_space_postion();
  short save_white = white;
  short save_black = black;
  int   i, point = (turn == BLACK ? MIN_LIMIT : MAX_LIMIT);
  for( i = 0; i < limit; i++ ){
    int value, pos = space[i];
    char piece_buffer[SIZE];

    /* 駒が置いてあるかチェックする */
    if( board[pos] != FREE ) continue;
    /* 駒を置く */
    if( !reverse_piece( pos, turn, piece_buffer ) ) continue;

    /* 終了チェック */
    if( black + white < P_SIZE ){
      if( turn == BLACK ){
	value = finish_white( point, FALSE );
      } else {
	value = finish_black( point, FALSE );
      }
    } else {
      value = black - white;
    }
    value_table[i] = value;
    /* 駒を元に戻す */
    {
      char *ptr = piece_buffer;
      char piece = (turn == BLACK ? WHITE : BLACK);
      board[pos] = FREE;
      white = save_white;
      black = save_black;
      do {
	board[*ptr++] = piece;
      } while( *ptr != -1 );
    }
    if((turn == BLACK && value > point) ||
       (turn == WHITE && value < point) ){
      point = value;
    }
  }
  /* NO_VALUE を後ろに集める */
  rsort( limit );
  /* NO_VALUE を除外する */
  while( value_table[limit - 1] == NO_VALUE ) limit--;
  if( turn == BLACK ) sort( limit ); else rsort( limit );
}  

/* 裏返す石をリストに格納 */
static void set_reverse_list( Tcl_Interp *interp, int n, int p )
{
  static Tcl_Obj *buff[SIZE];
  static char piece_buffer[SIZE];
  Tcl_Obj *result;
  int i , r;
  r = reverse_piece( n, p, piece_buffer );
  buff[0] = Tcl_NewIntObj( n );
  for( i = 0; i < r; i++ ){
    buff[i + 1] = Tcl_NewIntObj( piece_buffer[i] );
  }
  result = Tcl_NewListObj( r + 1, buff );
  Tcl_SetObjResult( interp, result );
  /* 駒数をセット */
  result = Tcl_NewIntObj( white );
  Tcl_SetVar2Ex(interp, "white_piece", NULL, result, TCL_LEAVE_ERR_MSG);
  result = Tcl_NewIntObj( black );
  Tcl_SetVar2Ex(interp, "black_piece", NULL, result, TCL_LEAVE_ERR_MSG);
}

/*
 * Tcl Command
 *
 * init_game             : ゲームの初期化
 * think $level $turn    : 思考ルーチン
 * reverse $n $piece     : ひっくり返る位置をリストで返す
 * check_reverse $n $p   : 駒を裏返すことができるか
 * count_place $turn     : 駒を置ける場所の数
 *
 */

/*
 * Tcl Command : init_game
 *
 */
static int InitGame(ClientData clientData,
		    Tcl_Interp *interp,
		    int objc,
		    Tcl_Obj *CONST objv[])
{
  if( objc != 1 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : init_game");
    return TCL_ERROR;
  }
  init_data();
  return TCL_OK;
}

/*
 * Tcl Command : count_place $turn
 *
 */
static int CountPlace(ClientData clientData,
		      Tcl_Interp *interp,
		      int objc,
		      Tcl_Obj *CONST objv[])
{
  Tcl_Obj *result;
  int turn, n;
  if( objc != 2 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : count_place $turn");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &turn ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( turn != 0 && turn != 1 ){
    return TCL_ERROR;
  }
  n = count_postion( turn );
  result = Tcl_NewIntObj( n );
  Tcl_SetObjResult( interp, result );
  return TCL_OK;
}

/*
 * Tcl Command : check_reverse $n $piece
 *
 */
static int CheckReverse(ClientData clientData,
		        Tcl_Interp *interp,
		        int objc,
		        Tcl_Obj *CONST objv[])
{
  Tcl_Obj *result;
  int n, p, r;
  if( objc != 3 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : check_reverse $n $piece");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &n ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[2], &p ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( n < 0 || n >= SIZE || (p != 0 && p != 1) ){
    return TCL_ERROR;
  }
  if( board[n] == FREE ){
    r = check_reverse( n, p );
  } else {
    r = 0;
  }
  result = Tcl_NewIntObj( r );
  Tcl_SetObjResult( interp, result );
  return TCL_OK;
}

/*
 * Tcl Command : reverse $n $piece
 *
 */
static int Reverse(ClientData clientData,
		   Tcl_Interp *interp,
		   int objc,
		   Tcl_Obj *CONST objv[])
{
  static Tcl_Obj *buff[SIZE];
  Tcl_Obj *result;
  int i, n, p, r;
  if( objc != 3 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : reverse $n $piece");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &n ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[2], &p ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( n < 0 || n >= SIZE || (p != 0 && p!= 1) ){
    return TCL_ERROR;
  }
  set_reverse_list( interp, n, p );
  return TCL_OK;
}

/* 指手の決定 */
static void decide_move( Tcl_Interp *interp, int turn, int random )
{
  int move = 0, i = 1, v = value_table[0];
  while( v == value_table[i] ) i++;
  /* 同じ値の手がある */
  if( i > 1 ){
    if( random ){
      /* 乱数で指手を決定する */
      move = rand() % i;
    }
  }
  /* 実際に動かす */
  set_reverse_list( interp, space[move], turn );
}

/*
 * Tcl Command : think $level $turn $random
 *
 */
static int ThinkMove(ClientData clientData,
		     Tcl_Interp *interp,
		     int objc,
		     Tcl_Obj *CONST objv[])
{
  int num  = white + black;
  int rest = P_SIZE - num;
  int level, turn, random;
  Tcl_Obj *result;
  if( objc != 4 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : think $level $turn $random");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &level ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( level < 0 ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[2], &turn ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( turn != 0 && turn != 1 ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[3], &random ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( random != 0 && random != 1 ){
    return TCL_ERROR;
  }
  /* 先読み手数は level + 1 */
  level++;
  /* 重みの設定 */
  if( num + level > 40 ){
    w1 = 30; w2 = 20;
  } else if( num + level > 20 ){
    w1 = 20; w2 = 20;
  } else {
    w1 = 20; w2 = 10;
  }
  /* 読み切りモードのチェック */
  if( level > 6 ){
    finish_move( turn );
  } else {
    search_move( turn, level );
  }
  /* 評価値を Tcl 変数へセットする */
  result = Tcl_NewIntObj( value_table[0] );
  Tcl_SetVar2Ex(interp, "VALUE", NULL, result, TCL_LEAVE_ERR_MSG);
  /* 指し手の決定 */
  decide_move( interp, turn, random );
  return TCL_OK;
}

/*
 * Tcl コマンドの初期化
 *
 */
int Octrev_Init( Tcl_Interp* interp )
{
  srand( time( NULL ) ); /* 乱数の初期化 */
  Tcl_CreateObjCommand(interp, "init_game", InitGame, NULL, NULL);
  Tcl_CreateObjCommand(interp, "reverse", Reverse, NULL, NULL);
  Tcl_CreateObjCommand(interp, "check_reverse", CheckReverse, NULL, NULL);
  Tcl_CreateObjCommand(interp, "think", ThinkMove, NULL, NULL);
  Tcl_CreateObjCommand(interp, "count_place", CountPlace, NULL, NULL);
  return Tcl_PkgProvide(interp, "octrev", "1.0");
}

/* end of file */

