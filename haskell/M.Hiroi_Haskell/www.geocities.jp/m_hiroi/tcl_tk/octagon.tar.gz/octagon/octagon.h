/***************************************************

  octagon.h : ８辺リバーシゲーム

              Copyright (C) 2005,2014 Makoto Hiroi


盤面

  0 | 1   2   3   4   5   6   7   8   9   10
 ---+----------------------------------------
 11 | **  **  14  15  16  17  18  19  **  **
 22 | **  24  25  26  27  28  29  30  31  **
 33 | 34  35  36  37  38  39  40  41  42  43
 44 | 45  46  47  48  49  50  51  52  53  54
 55 | 56  57  58  59  60  61  62  63  64  65
 66 | 67  68  69  70  71  72  73  74  75  76
 77 | 78  79  80  81  82  83  84  85  86  87
 88 | 89  90  91  92  93  94  95  96  97  98
 99 | ** 101 102 103 104 105 106 107 108  **
110 | **  ** 113 114 115 116 117 118  **  **
----+----------------------------------------
121 |122 123 124 125 126 127 128 129 130 131 132

****************************************************/
#include	<stdio.h>
#include	<stdlib.h>
#include	<time.h>
#include	<limits.h>
#include	<string.h>

#define	TRUE	1
#define	FALSE	0

/* 盤関係の定数 */
#define B_SIZE  133
#define B_START 14
#define B_END   119
#define	SIZE	100		/* 盤面の大きさ */
#define P_SIZE  88              /* 石の総数 */

#define	BLACK	0		/* 黒駒 */
#define	WHITE	1		/* 白駒 */
#define	FREE	2		/* 駒なし */
#define	WALL	4		/* 探索しない場所 */
#define	HUMAN	5		/* 人間側の手番 */
#define	COM	6		/* コンピュータ側の手番 */

#define	PASS	(-1)	/* パスした場合 */
#define	START	(-2)	/* 対局をクリックした場合 */

#define	FINISH	14	/* 読み切りモード */

#define	MAX_VALUE	100000
#define	MIN_VALUE	(-100000)
#define	NO_VALUE	INT_MAX

/* end of file */

