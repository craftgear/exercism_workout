/*
 * kalah.c : カラー思考ルーチン
 *
 *           Copyright (C) 1999-2005,2014 Makoto Hiroi
 *
 * コンパイル
 * gcc -O2 -shared -fPIC -okalah.so kalah.c
 *
 */
#include <tcl/tcl.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include <time.h>

/* 定数定義 */
typedef enum {
  FALSE = 0, TRUE, NORMAL, FINISH, KALAH,
} CODE;

#define SIZE      14
#define MY_KALAH   6
#define OPP_KALAH 13
#define HIS_SIZE  64
#define MOVE_SIZE 64
#define NO_VALUE  INT_MAX
#define MAX_VALUE 100
#define MIN_VALUE (-100)
#define EVEN_NUM  36
#define MOVE_END   0x20

/* 盤面の定義 */
typedef struct {
  char board[SIZE];
} BOARD;

static BOARD history[HIS_SIZE + 1];    /* 0 が現状の盤面を表す */

/* マクロ関数定義 */
#define GetStone(b, n)    (b)->board[(n)]
#define PutStone(b, n, s) (b)->board[(n)] = (s)
#define IncStone(b, n, s) (b)->board[(n)] += (s)

/* 石を配る : 終了位置を返す */
static int distribute( int turn, int pos, BOARD *b )
{
  int num = GetStone( b, pos );
  PutStone( b, pos, 0 );
  while( num > 0 ){
    /* 一周したか */
    if( ++pos >= SIZE ) pos = 0;
    /* 相手のカラーには配らない */
    if( (turn == MY_KALAH && pos != OPP_KALAH) ||
        (turn == OPP_KALAH && pos != MY_KALAH)){
      IncStone( b, pos, 1 );
      num--;
    }
  }
  return pos;
}

/* 両取りのチェック */
static int check_capture( int turn, int pos, BOARD *b )
{
  if( ((turn == MY_KALAH && (0 <= pos && pos <= 5)) ||
       (turn == OPP_KALAH && (7 <= pos && pos <= 12)))
      && (GetStone(b, pos) == 1)
      && (GetStone(b, (12 - pos)) > 0 )){
    /* 石を取り出す */
    int num = GetStone( b, (12 - pos)) + 1;
    PutStone( b, pos, 0 );
    PutStone( b, (12 - pos), 0 );
    IncStone( b, turn, num );
    return num;
  }
  return FALSE;
}

/* 穴に石があるか */
static int check_hole( int side, BOARD *b )
{
  int i = 0;
  int j = (side == MY_KALAH ? 0 : MY_KALAH + 1);
  for( ; i < MY_KALAH; i++, j++ ){
    if( GetStone( b, j ) > 0 ) return TRUE;
  }
  return FALSE;
}

/* 穴に残っている石をカラーに入れる */
static void stones_into_kalah( int side, BOARD * b )
{
  int i = 0;
  int j = (side == MY_KALAH ? 0 : MY_KALAH + 1);
  for( ; i < MY_KALAH; i++, j++ ){
    int n = GetStone( b, j );
    IncStone( b, side, n );
    PutStone( b, j, 0 );
  }
}

/* 終了チェック */
static int check_finish( BOARD * b )
{
  if( !check_hole( MY_KALAH, b ) ){
    stones_into_kalah( OPP_KALAH, b );
  } else if( !check_hole( OPP_KALAH, b ) ){
    stones_into_kalah( MY_KALAH, b );
  } else if( GetStone( b, MY_KALAH ) <= EVEN_NUM &&
             GetStone( b, OPP_KALAH ) <= EVEN_NUM ){
    return FALSE;
  }
  return TRUE;
}

/* 新しい盤面を作る */
static int make_new_board( int turn, int pos, int his )
{
  BOARD *b;
  history[his + 1] = history[his];
  b = &(history[his + 1]);
  pos = distribute( turn, pos, b );
  check_capture( turn, pos, b );
  if( check_finish( b ) ) return FINISH;
  else if( turn == pos ) return KALAH;
  return NORMAL;
}

/* 評価関数 */
static int value_func( BOARD *b )
{
  int my_value  = GetStone( b, MY_KALAH );
  int opp_value = GetStone( b, OPP_KALAH );
  if( my_value > EVEN_NUM ){
    return MAX_VALUE;
  } else if( opp_value > EVEN_NUM ){
    return MIN_VALUE;
  }
  return my_value - opp_value;
}

/* 探索本体 */
static int search( int depth, int his, int turn, int limit, char *move )
{
  int i, j, point = NO_VALUE;
  char buff[MOVE_SIZE + 1];
  BOARD *b = &(history[his]);
  if( depth == 0 || his >= HIS_SIZE ){
    *move = MOVE_END;
    return value_func( b );
  }

  j = (turn == OPP_KALAH ? MY_KALAH + 1 : 0);
  for( i = 0; i < MY_KALAH; i++, j++ ){
    if( GetStone(b, j) > 0 ){
      int value;
      int result = make_new_board( turn, j, his );
      switch( result ){
      case FINISH:
	value = value_func( &(history[his + 1]) );
	break;
      case KALAH:
	value = search( depth, his + 1, turn, limit, buff );
	break;
      default:
	value = search( depth - 1,
		        his + 1,
		        (turn == MY_KALAH ? OPP_KALAH : MY_KALAH),
		        point,
		        buff );
      }

      /* ミニマックス心臓部 */
      if( (point == NO_VALUE) ||
	  (turn == OPP_KALAH && value < point) ||
	  (turn == MY_KALAH  && point < value) ||
	  (point == value && (rand() % 10) < 2) ){
	point = value;
	*move = j;
	if( result == KALAH ){
          /* 指し手をコピーする */
	  char *sptr = buff;
	  char *dptr = move + 1;
	  while( *sptr != MOVE_END ) *dptr++ = *sptr++;
	  *dptr = MOVE_END;
	} else {
	  *(move + 1) = MOVE_END;
	}
      }

      /* αβ枝刈り */
      if( (limit != NO_VALUE) &&
	  ((turn == OPP_KALAH && point < limit) ||
	   (turn == MY_KALAH  && point > limit)) ){
	break;
      }
    }
  }
  return point;
}

/* 指し手をリストに変換して結果に格納する */
static void set_move_list( Tcl_Interp *interp, char *move )
{
  int i = 0;
  Tcl_Obj *buffer[MOVE_SIZE + 1];
  Tcl_Obj *result;
  for( ; *move != MOVE_END; move++, i++ ){
    buffer[i] = Tcl_NewIntObj( *move );
  }
  result = Tcl_NewListObj( i, buffer );
  Tcl_SetObjResult( interp, result );
}

/*
 * Tcl Command : think $depth $turn board
 *
 *  $depth : 思考の深さ
 *  $turn  : OPP_KALAH or MY_KALAH
 *  board  : 盤面を格納する配列名
 *
 *  返り値は指し手を格納したリスト
 */
static int KalahCommand(ClientData clientData,
			Tcl_Interp *interp,
			int objc,
			Tcl_Obj *CONST objv[])
{
  static char *number[SIZE] = {
    "0", "1", "2",  "3",  "4",  "5",  "6",
    "7", "8", "9", "10", "11", "12", "13",
  };
  char *ptr;
  char move[MOVE_SIZE + 1];
  int  i, depth, turn, value;
  /* 引数チェック */
  if( objc != 4 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : think $depth $turn board");
    return TCL_ERROR;
  }
  /* 引数ゲット！ */
  if( Tcl_GetIntFromObj(interp, objv[1], &depth ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( depth < 1 || depth > 10 ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[2], &turn ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( turn != MY_KALAH && turn != OPP_KALAH ){
    return TCL_ERROR;
  }
  /* 配列より盤面を取得 */
  ptr = Tcl_GetString( objv[3] );
  for( i = 0; i < SIZE; i++ ){
    Tcl_Obj *n = Tcl_GetVar2Ex( interp, ptr, number[i], TCL_LEAVE_ERR_MSG );
    if( Tcl_GetIntFromObj( interp, n, &value ) != TCL_OK ){
      return TCL_ERROR;
    }
    if( value < 0 || value > EVEN_NUM ){
      return TCL_ERROR;
    }
    PutStone( &(history[0]), i, value );
  }
  /* 探索 */
  /* １手で止めを刺せるか */
  if( (value = search( 1, 0, turn, NO_VALUE, move )) != MIN_VALUE ){
    /* 通常の探索 */
    search( depth, 0, turn, NO_VALUE, move );
  }
  /* 指し手をリストに格納して結果に格納 */
  set_move_list( interp, move );
  return TCL_OK;
}

/*
 *  Kalah_Init : think コマンドの初期化
 *
 */
int Kalah_Init( Tcl_Interp* interp )
{
  srand( time( NULL ) );
  Tcl_CreateObjCommand(interp, "think", KalahCommand, NULL, NULL);
  return Tcl_PkgProvide(interp, "kalah", "1.1");
}

/* end of file */
