/**********************************************************

  updepon.h : ゲーム「アップでポン」定義ファイル

              Copyright (C) 1999-2005,2014 Makoto Hiroi

**********************************************************/
#ifndef _UPDEPON_H_
#define _UPDEPON_H_

#include <stdlib.h>
#include <limits.h>
#include <time.h>

/* 定数定義 */
typedef enum {
  FALSE, TRUE,
} Bool;

/* 赤が先手、青が後手 */
typedef enum {
  FREE, RED, BLUE, NATURAL,
} BallType;

typedef enum {
  OFF, ON, EXCEPT,    /* OFF : 玉積み不可, ON : 玉積み可, EXCEPT : 探索除外 */
} FlagType;

#define SIZE4     30
#define SIZE5     55
#define SIZE6     91
#define SIZE7    140
#define SIZE8    204
#define SIZE9    285

#define NO_VALUE  INT_MAX
#define MAX_VALUE 100000
#define MIN_VALUE (-100000)

/* 最大探索レベル */
#define MAX_HIS  4

/* 場所の状態 */
typedef struct {
  char  type;     /* 玉の種別 */
  char  flag;     /* 玉を置けるか */
} State;


#endif

/* end of file */
