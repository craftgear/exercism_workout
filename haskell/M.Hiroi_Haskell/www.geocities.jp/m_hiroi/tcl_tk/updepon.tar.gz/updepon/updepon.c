/*****************************************************

  updepon.c : アップでポン 思考ルーチン

              Copyright (C) 1999-2005 Makoto Hiroi

コンパイル
gcc -O2 -shared -fPIC -oupdepon.so updepon.c data.c

*****************************************************/
#include <tcl/tcl.h>
#include "updepon.h"

/* data.c */
extern short up_ball_data[SIZE9][5];
extern short down_ball_data[SIZE8][4];

/* 盤面の定義 */
static State board[SIZE9];
static int   rest_red;
static int   rest_blue;

/* マクロ関数 */
#define GetType( n )    board[(n)].type
#define GetFlag( n )    board[(n)].flag
#define PutType( n, c ) board[(n)].type = (c)
#define PutFlag( n, c ) board[(n)].flag = (c)

/* 探索用ワーク（スタックとして使用する） */
static State back_state[SIZE9];    /* 状態を退避する */
static short back_pos[SIZE9];      /* 書き換えた位置 */
static int   back_rcnt[MAX_HIS + 1];
static int   back_bcnt[MAX_HIS + 1];
static int   back_sp[MAX_HIS + 1];
static int   bp;

/* 玉積み上げ用キュー */
static short n_queue[MAX_HIS + 1][SIZE5];
static char  c_queue[MAX_HIS + 1][SIZE5];
static short rp[MAX_HIS + 1];
static short wp[MAX_HIS + 1];

/* 評価値計算用ワーク */
static int work_table[SIZE9];

/* 盤面のサイズ */
static int board_size;
static int max_size;

/* 評価関数 */
static int (*func)( void );

/* 操作関数 */

/* ワークの初期化 */
static void init_work( int his )
{
  if( his == 0 ){
    bp = 0;
  }
  back_sp[his] = bp;
  back_rcnt[his] = rest_red;
  back_bcnt[his] = rest_blue;
}
  
/* ワークにプッシュ */
static void push_work( int n )
{
  back_pos[bp] = n;
  back_state[bp] = board[n];
  bp++;
}

/* 指し手をリストに変換して結果に格納する */
static void set_move_list( Tcl_Interp *interp )
{
  static Tcl_Obj *item[SIZE5 * 2];
  Tcl_Obj *list;
  int i = 0, j = 0;
  for( ; i < bp; i++ ){
    int n = back_pos[i];
    int c = GetType( n );
    if( c ){
      /* c が 0 の場合は、状態のみの書き換え */
      item[j++] = Tcl_NewIntObj( n );
      item[j++] = Tcl_NewIntObj( c );
    }
  }
  list = Tcl_NewListObj( j, item );
  Tcl_SetObjResult( interp, list );
}


/* 元に戻す */
static void pop_work( int his )
{
  int p = bp;
  bp = back_sp[his];
  while( --p >= bp ){
    int n = back_pos[p];
    board[n] = back_state[p];
  }
  rest_red   = back_rcnt[his];
  rest_blue = back_bcnt[his];
}

/* キューの初期化 */
static void init_queue( int his )
{
  wp[his] = 0;
  rp[his] = 0;
}

/* データの追加 */
static int enqueue( int his, int pos, int c )
{
  if( wp[his] >= SIZE5 ) return FALSE;
  n_queue[his][wp[his]] = pos;
  c_queue[his][wp[his]] = c;
  wp[his]++;
  return TRUE;
}

/* データを取り出す */
static int dequeue( int his, int *pos, int *c )
{
  if( wp[his] == rp[his] ) return FALSE;
  *pos = n_queue[his][rp[his]];
  *c   = c_queue[his][rp[his]];
  rp[his]++;
  return TRUE;
}

/* 盤面の初期化 */
static void init_board( int size )
{
  /* 初期化データ */
  static short init_data5[9] = {
    42, 36, 37, 38, 41, 43, 46, 47, 48,
  };
  static short init_data7[9] = {
    115, 107, 108, 109, 114, 116, 121, 122, 123,
  };
  static short init_data9[9] = {
    244, 234, 235, 236, 243, 245, 252, 253, 254,
  };
  int   i, n;
  short *ptr;
  switch( size ){
  case 5:
    n = SIZE4; max_size = SIZE5; ptr = init_data5;
    rest_red = 28; rest_blue = 26;
    break;
  case 7:
    n = SIZE6; max_size = SIZE7; ptr = init_data7;
    rest_red = 71; rest_blue = 68;
    break;
  case 9:
    n = SIZE8; max_size = SIZE9; ptr = init_data9;
    rest_red = 144; rest_blue = 140;
    break;
  }
  for( i = 0; i < SIZE9; i++ ){
    PutType( i, 0 );
    PutFlag( i, OFF );
  }
  /* 底面は玉を置ける */
  for( i = n; i < max_size; i++ ){
    PutType( i, 0 );
    PutFlag( i, EXCEPT );
  }
  /* 中立の玉をセット */    
  board[*ptr].type = NATURAL;
  board[*ptr].flag = OFF;
  for( i = 1, ptr++; i < 9; i++, ptr++ ){
    board[*ptr].flag = ON;   /* 中立玉の回りは探索 OK */
  }
}

/* 下の玉を数える */
static int count_down_ball( int num, int *red, int *blue )
{
  int r = 0;
  int b = 0;
  int n = 0;
  int i = 0;
  for( ; i < 4; i++ ){
    int t = GetType( down_ball_data[num][i] );
    switch( t ){
    case RED:     r++; break;
    case BLUE:    b++; break;
    case NATURAL: n++; break;
    }
  }
  *red = r;
  *blue = b;
  return r + b + n;
}

/* 探索除外を解除 */
static void delete_except( int num )
{
  if( (board_size == 5 && num > SIZE4) ||
      (board_size == 7 && num > SIZE6) ||
      (board_size == 9 && num > SIZE8) ){
    short *p = up_ball_data[num];
    for( ; *p != -1; p++ ){
      int i;
      for( i = 0; i < 4; i++ ){
        int    j = down_ball_data[*p][i];
        if( GetFlag( j ) == EXCEPT ){
	  push_work( j );
	  PutFlag( j, ON );
	}
      }
    }
  }
}

/* 玉を置く */
static void put_ball( int his, int num, int color )
{
  /* ワークの初期化 */
  init_work( his );       /* rest_red, rest_blue も退避する */
  init_queue( his );
  /* 玉の数を減らす */
  (color == RED ? rest_red-- : rest_blue-- );

  for(;;){
    const short *ptr;
    /* 玉をセットする */
    push_work( num );
    PutType( num, color );
    PutFlag( num, OFF );
    /* 底面の場合は探索除外を解除 */
    delete_except( num );
    /* 上に玉を積めるか */
    for( ptr = up_ball_data[num]; *ptr != -1; ptr++ ){
      int red, blue, p = *ptr;
      /* チェックする */
      if( count_down_ball( p, &red, &blue ) == 4 ){
	/* ４つ揃ったよ */
	if( red >= 3 && rest_red ){
	  rest_red--;
	  enqueue( his, p, RED );
	} else if( blue >= 3 && rest_blue ){
	  rest_blue--;
	  enqueue( his, p, BLUE );
	} else {
	  push_work( p );
	  PutFlag( p, ON );
	}
      }
    }
    /* キューよりデータを取り出す */
    if( !dequeue( his, &num, &color ) ) break;
  }
}

/********** 評価関数 **********/
/* 青の評価点を正、赤の評価点を負とする */

/* 玉数基準の弱いルーチン */
static int value_func1( void )
{
  int rv = 0;
  int bv = 0;
  int i = max_size - 1;
  for( ; i >= 0; i-- ){
    int type = GetType( i );
    switch( type ){
    case FREE:
      {
	int r, b;
	count_down_ball( i, &r, &b );
	if( r >= 3 ){
	  rv += 3;
	} else if( b >= 3 ){
	  bv += 3;
	} else {
	  if( r >= 2 ) rv += 2;
	  if( b >= 2 ) bv += 2;
	}
	break;
      }
    case RED:
      rv += 4; break;
    case BLUE:
      bv += 4; break;
    }
  }
  return bv - rv;
}

/* 評価関数その２ */
static int value_func2( void )
{
  int value = 0;
  int i;
  for( i = max_size - 1; i >= 0; i-- ){
    int type = GetType( i );
    switch( type ){
    case FREE:
      if( !(GetFlag( i ) == OFF) ){
	/* 自由における場所は 0.5 (128) */
	work_table[i] = 128;
      } else {
	/* 下の状態をチェック、足して４で割る */
	int p, j;
	for( j = 0, p = 0; j < 4; j++ ){
	  p += work_table[ down_ball_data[i][j] ];
	}
	work_table[i] = p / 4;
      }
      break;
    case BLUE:
      work_table[i] = 256; break;
    default:
      /*
       * 青玉（正の値）を基準に評価値を計算するので
       * 赤玉は 0 をセットする。これでもきちんと動作するよ。
       */
      work_table[i] = 0;
    }
    value += work_table[i];
  }
  return value;
}

/*
 * 評価関数その３
 * (森田和郎氏の評価関数を参考)
 *
 */
/* 確率計算 1.0 --> 16 として計算する（精度は森田式よりも低い） */
static int probability( int n )
{
  int p1 = work_table[ down_ball_data[n][0] ];
  int p2 = work_table[ down_ball_data[n][1] ];
  int p3 = work_table[ down_ball_data[n][2] ];
  int p4 = work_table[ down_ball_data[n][3] ];

  int pm1 = 16 - p1;
  int pm2 = 16 - p2;
  int pm3 = 16 - p3;
  int pm4 = 16 - p4;
  int p12 = p1 * p2;
  int p34 = p3 * p4;
  int p1pm2 = p1 * pm2;
  int p2pm1 = p2 * pm1;
  int p3pm4 = p3 * pm4;
  int p4pm3 = p4 * pm3;

  int value = (pm1 * pm2 * p34 
	        + (p4pm3 + p3pm4) * (p2pm1 + p1pm2)
	        + pm3 * pm4 * p12) * 8;
  value += ((p12 + p2pm1 + p1pm2) * p34 + (p3pm4 + p4pm3) * p12) * 16;
  return value >> 16;
}

static int value_func3( void )
{
  int value = 0;
  int i;
  for( i = max_size - 1; i >= 0; i-- ){
    int type = GetType( i );
    switch( type ){
    case FREE:
      if( !(GetFlag( i ) == OFF) ){
	work_table[i] = 8;
      } else {
	work_table[i] = probability( i );
      }
      break;
    case BLUE:
      work_table[i] = 16; break;
    default :
      work_table[i] = 0;
    }
    value += work_table[i];
  }
  return value;
}

/* 思考ルーチン（反復深化は使わない） */
static int think( int depth, int his, int turn, int limit, int *move )
{
  int i, buff, point = NO_VALUE;
  if( depth == 0 ){
    return (*func)();   /* 評価関数はレベルによって選択する */
  }
  for( i = 0; i < max_size; i++ ){
    int value;
    if( GetFlag( i ) != ON ) continue;
    put_ball( his, i, turn );
    /* ゲーム終了判定 */
    if( rest_blue == 0 || rest_red == 0 ){
      value = rest_red - rest_blue;
      if( value < 0 ){
	value += MIN_VALUE;    /* 赤の勝ち */
      } else {
	value += MAX_VALUE;    /* 青の勝ち */
      }
    } else {
      /* 再帰する */
      value = think(depth - 1, his + 1, (turn == RED ? BLUE : RED), point, &buff);
    }
    /* 状態を元に戻す */
    pop_work( his );
    /* ミニマックス */
    if( (point == NO_VALUE) ||
        (turn == BLUE && value > point) ||
        (turn == RED  && value < point) ||
        (point == value && (rand() % 10) < 2) ){
      point = value;
      *move = i;
    }
    /* αβ枝刈り */
    if( (limit != NO_VALUE) &&
        ((turn == BLUE && point > limit) ||
	 (turn == RED  && point < limit)) ){
      break;
    }
  }
  return point;
}

/* 残り玉数を Tcl の変数にセット */
static void set_ball_count( Tcl_Interp *interp )
{
  Tcl_Obj *np;
  np = Tcl_NewIntObj( rest_red );
  Tcl_SetVar2Ex(interp, "red_ball", NULL, np, TCL_LEAVE_ERR_MSG);
  np = Tcl_NewIntObj( rest_blue );
  Tcl_SetVar2Ex(interp, "blue_ball", NULL, np, TCL_LEAVE_ERR_MSG);
}
    
/*
 * Tcl Command
 *
 * think $level $turn : 思考
 * search_place       : ボールを置ける場所をリストで返す
 * put_ball $n $c     : ボールを置く
 *                      その後に積みあがるボールの種類と場所をリストで返す
 * init_game $size    : ゲームの初期化
 *
 */

/*
 * Tcl Command : init_game $size
 *
 */
static int InitGame(ClientData clientData,
		    Tcl_Interp *interp,
		    int objc,
		    Tcl_Obj *CONST objv[])
{
  if( objc != 2 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : init_game $board_size");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &board_size ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( board_size != 5 && board_size != 7 && board_size != 9 ){
    return TCL_ERROR;
  }
  init_board( board_size );
  set_ball_count( interp );
  return TCL_OK;
}

/*
 * Tcl Command : search_place
 *
 */
static int SearchPlace(ClientData clientData,
		   Tcl_Interp *interp,
		   int objc,
		   Tcl_Obj *CONST objv[])
{
  static Tcl_Obj *buff[80];
  Tcl_Obj *list;
  int i, k;
  if( objc != 1 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : search_place");
    return TCL_ERROR;
  }
  for( i = 0, k = 0; i < max_size; i++ ){
    if( GetFlag( i ) != OFF ){
      buff[k++] = Tcl_NewIntObj( i );
    }
  }
  list = Tcl_NewListObj( k, buff );
  Tcl_SetObjResult( interp, list );
  return TCL_OK;
}

/*
 * Tcl Command : put_ball $n $c
 *
 */
static int PutBall(ClientData clientData,
		   Tcl_Interp *interp,
		   int objc,
		   Tcl_Obj *CONST objv[])
{
  int n, c;
  if( objc != 3 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : put_ball $n $c");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &n ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( n < 0 || n >= SIZE9 || GetFlag( n ) == OFF ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[2], &c ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( c != RED && c != BLUE ) return TCL_ERROR;

  /* ボールを置く */
  put_ball( 0, n, c );
  /* 積まれる玉をリストに格納して返す */
  set_move_list( interp );
  set_ball_count( interp );
  return TCL_OK;
}

/*
 * Tcl Command : think $level $turn
 *
 */
static int ThinkMove(ClientData clientData,
		     Tcl_Interp *interp,
		     int objc,
		     Tcl_Obj *CONST objv[])
{
  int level, turn, depth, move;
  if( objc != 3 ){
    Tcl_WrongNumArgs(interp, 1, objv, "Usage : think $level $turn");
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[1], &level ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( Tcl_GetIntFromObj(interp, objv[2], &turn ) != TCL_OK ){
    return TCL_ERROR;
  }
  if( turn != RED && turn != BLUE ) return TCL_ERROR;
  switch( level ){
  case 1: depth = 2; func = value_func1; break;
  case 2: depth = 3; func = value_func1; break;
  case 3: depth = 1; func = value_func2; break;
  case 4: depth = 3; func = value_func2; break;
  case 5: depth = 1; func = value_func3; break;
  case 6: depth = 3; func = value_func3; break;
  default:
    depth = MAX_HIS; func = value_func3;
  }
  /* 指し手の決定 */
  think( depth, 0, turn, NO_VALUE, &move );
  /* 実際に動かす */
  put_ball( 0, move, turn );
  /* 積まれる玉をリストに格納して返す */
  set_move_list( interp );
  set_ball_count( interp );
  return TCL_OK;
}

/*
 * Tcl コマンドの初期化
 *
 */
int Updepon_Init( Tcl_Interp* interp )
{
  srand( time( NULL ) ); /* 乱数の初期化 */
  Tcl_CreateObjCommand(interp, "init_game", InitGame, NULL, NULL);
  Tcl_CreateObjCommand(interp, "put_ball", PutBall, NULL, NULL);
  Tcl_CreateObjCommand(interp, "search_place", SearchPlace, NULL, NULL);
  Tcl_CreateObjCommand(interp, "think", ThinkMove, NULL, NULL);
  return Tcl_PkgProvide(interp, "updepon", "1.1");
}

/* end of file */
