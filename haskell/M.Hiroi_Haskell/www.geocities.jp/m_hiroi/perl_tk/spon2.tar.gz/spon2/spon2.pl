#! /usr/bin/perl
#
# spon2.pl : そろえてポン２（菱形バージョン）
#
#           Copyright (C) 2004, 2014 Makoto Hiroi
#

use utf8;
use Tk;
use Tk::Dialog;
use File::Basename;

# グローバル変数の定義
@board = (
  [0,0,0,1,0,0,0],
  [0,0,1,1,1,0,0],
  [0,1,1,1,1,1,0],
  [1,1,1,1,1,1,1],
  [0,1,1,1,1,1,0],
  [0,0,1,1,1,0,0],
  [0,0,0,1,0,0,0]
);

# 色の定義
$color_number = 2;
@color_table = ('white', 'yellow', 'green', 'blue', 'red' );

# ヘルプウィンドウ
$help_window = 0;

# レベル(初期値は EASY)
$level = 3;

# パネルの色
@panel_color = ();

# パネルを表す図形 ID
@panel_id = ();

# パネルの座標
@panel_x = (
           3,
        2, 3, 4,
     1, 2, 3, 4, 5,
  0, 1, 2, 3, 4, 5, 6, 
     1, 2, 3, 4, 5,
        2, 3, 4,
           3 );
@panel_y = (
           0,
        1, 1, 1,
     2, 2, 2, 2, 2,
  3, 3, 3, 3, 3, 3, 3,
     4, 4, 4, 4, 4,
        5, 5, 5,
           6 );

# スタートを保存
sub save_start {
  my $i;
  for( $i = 0; $i < 25; $i++ ){
    my $x = $panel_x[$i];
    my $y = $panel_y[$i];
    $save_start[$x][$y] = $panel_color[$x][$y];
  }
}

# スタートを復元
sub restore_start {
  my $i;
  for( $i = 0; $i < 25; $i++ ){
    my $x = $panel_x[$i];
    my $y = $panel_y[$i];
    $panel_color[$x][$y] = $save_start[$x][$y];
  }
}

# 白に揃ったか
sub check_finish {
  my ($x, $y, $i);
  for( $i = 0; $i < 25; $i++ ){
    $x = $panel_x[$i];
    $y = $panel_y[$i];
    return 0 if $panel_color[$x][$y] != 0; 
  }
  return 1;
}


# 初期状態を作る
sub init_panel {
  my ($x, $y, $i, $n, $p);
  my @use_flag = ();
  for( $i = 0; $i < 25; $i++ ){
    $x = $panel_x[$i];
    $y = $panel_y[$i];
    $panel_color[$x][$y] = 0;
    $c0->itemconfigure( $panel_id[$x][$y], -fill => 'white' );
  }
  for( $i = 0; $i < 25; $i += $level ){
    while( 1 ){
      # 押していない場所を選ぶ
      $p = int( rand( 25 ) );
      unless( $use_flag[$p] ){
        $use_flag[$p] = 1;
        last;
      }
    }
    # 押す回数を選ぶ
    $n = int( rand( $color_number ) );
    while( $n-- > 0 ){
      # 0 はダミー
      push_panel( 0, $panel_x[$p], $panel_y[$p] );
    }
  }
}

# ゲーム開始
sub new_game {
  # 盤面を作る
  while( 1 ){
    &init_panel();
    unless( &check_finish() ){
      &save_start();
      last;
    }
  }
  # 初期化
  $now_step = 0;
  $min_step = 999;
  &display_step();
}

# 最初からやり直し
sub retry_game {
  $now_step = 0;
  &restore_start();
  my $i;
  for( $i = 0; $i < 25; $i++ ){
    my $x = $panel_x[$i];
    my $y = $panel_y[$i];
    $c0->itemconfigure( $panel_id[$x][$y], -fill => $color_table[ $panel_color[$x][$y] ] );
  }
  &display_step();
}


# パネルを押す
sub push_panel {
  my ($obj, $x, $y) = @_;
  my @dx = (0, 1, -1, 0, 0);
  my @dy = (0, 0, 0, 1, -1);
  my $i;
  for( $i = 0; $i < 5; $i++ ){
    my $x1 = $x + $dx[$i];
    my $y1 = $y + $dy[$i];
    if( $x1 >= 0 && $x1 < 7 && $y1 >= 0 && $y1 < 7 && $board[$x1][$y1] ){
      my $c = ($panel_color[$x1][$y1] + 1) % $color_number;
      $panel_color[$x1][$y1] = $c;
      $c0->itemconfigure( $panel_id[$x1][$y1], -fill => $color_table[$c] );
    }
  }
  $now_step++;
  &display_step();
  if( &check_finish() ){
    $min_step = $now_step if $min_step > $now_step;
    $dialog->Show();
    &retry_game();
  }
}

# ステップ数の表示
sub display_step {
  $output_label = sprintf("Min Steps %3d : Steps %3d", $min_step, $now_step);
}

# ヘルプの表示
sub help {
  if( !$help_window or !Exists( $help_window ) ){
    $help_window = MainWindow->new();
    $help_window->title("Help");
    $t0 = $help_window->Scrolled( 'Text', -scrollbars => 'se' )->pack();
    $t0->configure( -font => 'Takaoゴシック 12' );
    # パスを取得
    $dir = &dirname( $0 );
    open(IN, "<:utf8", "$dir/spon2.txt");
    while( <IN> ){
      $t0->insert( 'end', $_ );
    }
    close( IN );
    $t0->configure( -state => 'disable' );
  }
  $help_window->focusForce();
}

# ***** メインウィンドウの設定 *****
$top = MainWindow->new();

# メニューの設定
$m = $top->Menu( -type => 'menubar' );
$top->configure( -menu => $m );

$m1 = $m->cascade(-label => 'Games', -under => 0, -tearoff => 0);
$m2 = $m->cascade(-label => 'Level', -under => 0, -tearoff => 0);
$m3 = $m->command(-label => 'Retry', -under => 0, -command => \&retry_game);
$m4 = $m->command(-label => 'Help',  -under => 0, -command => \&help);

$m1->command(-label => 'New Game', -under => 0, -command => \&new_game );
$m1->separator;
$m1->radiobutton(-label => '2 colors', -variable => \$color_number, -value => 2);
$m1->radiobutton(-label => '3 colors', -variable => \$color_number, -value => 3);
$m1->radiobutton(-label => '4 colors', -variable => \$color_number, -value => 4);
$m1->radiobutton(-label => '5 colors', -variable => \$color_number, -value => 5);
$m1->separator;
$m1->command(-label => 'Exit', -under => 0, -command => \&exit );

$m2->radiobutton(-label => 'Easy',   -under => 0, -variable => \$level, -value => 3);
$m2->radiobutton(-label => 'Normal', -under => 0, -variable => \$level, -value => 2);
$m2->radiobutton(-label => 'Hard',   -under => 0, -variable => \$level, -value => 1);

# ステップ表示用ラベルの設定
$l0 = $top->Label( -textvariable => \$output_label, -font => 'Takaoゴシック 14', -bg => 'gray' )->pack( -fill => 'x' );

# キャンバスウィジェットの設定
$c0 = $top->Canvas( -width => 300, -height => 300, -bg => 'gray' );

# 図形の初期化
for( $x = 0; $x < 7; $x++ ){
  $x1 = $x * 40 + 11;
  $panel_id[$x] = [];
  $panel_color[$x] = [];
  $save_start[$x] = [];
  for( $y = 0; $y < 7; $y++ ){
    $y1 = $y * 40 + 11;
    if( $board[$x][$y] ){
      my $id = $c0->create('rectangle', $x1, $y1, $x1 + 38, $y1 + 38, -fill => 'white' );
      $c0->bind( $id, "<Button-1>" => [\&push_panel, $x, $y] );
      $panel_id[$x][$y] = $id;
      $panel_color[$x][$y] = 0;
    }
  }
}

$c0->pack();

# ダイアログ
$dialog = $top->Dialog( -text => 'Congratulation!' );

# メインウィンドウの設定
$top->title("SoroetePon! 2");
$top->focus();

# メインループ
MainLoop();

# end of file
