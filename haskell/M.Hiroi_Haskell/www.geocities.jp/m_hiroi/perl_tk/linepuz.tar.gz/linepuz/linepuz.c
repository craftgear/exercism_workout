/*
 * linepuz.c : ラインパズルの解法
 *
 *             Copyright (C) 2004, 2014 Makoto Hiroi
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 定数の定義 */
#define TRUE       1
#define FALSE      0
#define SIZE      16
#define PAT_SIZE  16
#define MAX_MOVE 100

/* 種別の定義
 *
 *  A C
 *  B D
 */
#define S 0
#define A 1
#define B 2
#define C 3
#define D 4


/* 隣接リスト
    0  1  2  3
    4  5  6  7
    8  9 10 11
   12 13 14 15
*/
const char adjacent[SIZE][5] = {
   1,  4, -1, -1, -1,  /* 0 */
   0,  2,  5, -1, -1,  /* 1 */
   1,  3,  6, -1, -1,  /* 2 */
   2,  7, -1, -1, -1,  /* 3 */
   0,  5,  8, -1, -1,  /* 4 */
   1,  4,  6,  9, -1,  /* 5 */
   2,  5,  7, 10, -1,  /* 6 */
   3,  6, 11, -1, -1,  /* 7 */
   4,  9, 12, -1, -1,  /* 8 */
   5,  8, 10, 13, -1,  /* 9 */
   6,  9, 11, 14, -1,  /* 10 */
   7, 10, 15, -1, -1,  /* 11 */
   8, 13, -1, -1, -1,  /* 12 */
   9, 12, 14, -1, -1,  /* 13 */
  10, 13, 15, -1, -1,  /* 14 */
  11, 14, -1, -1, -1,  /* 15 */
};

/* パターン */
char pattern_a[SIZE] = {
  A, C, A, S,
  B, A, C, D,
  A, B, D, C,
  B, D, B, D,
};

char pattern_b[SIZE] = {
  A, C, A, S,
  B, B, A, D,
  A, D, C, C,
  B, D, B, D,
};

char pattern_c[SIZE] = {
  A, B, A, S,
  B, D, B, A,
  D, C, A, C,
  B, D, C, D,
};

char pattern_d[SIZE] = {
  A, C, A, S,
  B, D, B, D,
  A, C, A, C,
  B, D, B, D,
};

char pattern_e[SIZE] = {
  A, A, C, S,
  A, A, C, C,
  B, B, D, D,
  B, B, D, D,
};

char pattern_f[SIZE] = {
  A, C, A, S,
  D, B, D, B,
  C, A, C, A,
  B, D, B, D,
};

const char *start_pattern[PAT_SIZE] = {
  NULL,
  pattern_a,  pattern_b,  pattern_d,  pattern_a,  pattern_b,
  pattern_f,  pattern_c,  pattern_e,  pattern_b,  pattern_f,
  pattern_c,  pattern_a,  pattern_c,  pattern_e,  pattern_f,
};

const char *goal_pattern[PAT_SIZE] = {
  NULL,
  pattern_b,  pattern_d,  pattern_a,  pattern_e,  pattern_f,
  pattern_d,  pattern_f,  pattern_b,  pattern_c,  pattern_a,
  pattern_d,  pattern_c,  pattern_e,  pattern_d,  pattern_e,
};

/* ゴール */
const char *final_state;

/* 盤面 */
char board[SIZE];

/* 動かした駒 */
char move_piece[MAX_MOVE + 1];
char prev_move[MAX_MOVE + 1];

/*
 * 移動手数表
 *
 */
int distance[5][16];

void make_distance( void )
{
  int i, j, k, m, n;
  int x[4], y[4];
  for( i = 1; i < 5; i++ ){
    /* 座標セット */
    for( k = j = 0; j < SIZE; j++ ){
      if( final_state[j] == i ){
        x[k] = j % 4;
        y[k] = j / 4;
        if( ++k == 4 ) break;
      }
    }
    /* 距離をセット */
    for( j = 0; j < SIZE; j++ ){
      int x1 = j % 4;
      int y1 = j / 4;
      if( final_state[j] == i ){
        m = 0;
      } else {
        for( m = SIZE, n = 0; n < k; n++ ){
          int d = (x1 > x[n] ? x1 - x[n] : x[n] - x1) +
            (y1 > y[n] ? y1 - y[n] : y[n] - y1);
          if( d < m ) m = d;
        }
      }
      distance[i][j] = m;
    }
  }
}

/* 下限値を求める */
int calc_lower_value( const char *board )
{
  int i, j, d = 0;
  for( i = 0; i < SIZE; i++ ){
    j = board[i];
    if( j > 0 ) d += distance[j][i];
  }
  return d;
}


/* 初期化 */
int init( const char *init_pattern )
{
  memcpy( board, init_pattern, SIZE );
  move_piece[0] = -1;
  prev_move[0] = -1;
  make_distance();
  return calc_lower_value( init_pattern );
}

/* 手順を表示 */
void print_answer( int m )
{
  int i;
  printf("%d 手で解けました\n", m + 2 );
  printf("-----------\n");
  printf("          E\n");
  printf(" 0  1  2  3\n");
  printf(" 4  5  6  7\n");
  printf(" 8  9 10 11\n");
  printf("12 13 14 15\n");
  printf("-----------\n");
  printf(" 3 ");
  for( i = 1; i <= m; i++ ){
    if( i % 5 == 0 ) printf("\n");
    printf("%2d ", move_piece[i] );
  }
  printf(" E\n");
}

/* 下限値枝刈り法 */
void solve_low( int limit, int move, int space, int low )
{
  if( move == limit ){
    if( !memcmp( board, final_state, SIZE ) ){
      /* 解をひとつ見つけたら終了 */
      print_answer( move );
      exit( 0 );
    }
  } else {
    int i, j, new_low;
    for( i = 0; (j = adjacent[space][i]) != -1; i++ ){
      int p = board[j];
      if( prev_move[move] == j ) continue;
      /* 移動する */
      board[space] = p;
      board[j] = 0;
      move_piece[move + 1] = j;
      prev_move[move + 1] = space;
      new_low = low - distance[p][j] + distance[p][space];

      /* 下限値による枝刈り */
      if( new_low + move <= limit ){
        solve_low( limit, move + 1, j, new_low );
      }
      /* 元に戻す */
      board[space] = 0;
      board[j] = p;
    }
  }
}

void usage( void )
{
  fprintf(stderr,"usage: linepuz stage_number\n");
  fprintf(stderr,"       stage_number = 1 - 15\n");
  exit( 1 );
}

int main( int argc, char *argv[] )
{
  int n, low, limit;
  if( argc != 2 ) usage();
  n = atoi( argv[1] );
  if( n < 1 || n >= PAT_SIZE ) usage();
  final_state = goal_pattern[n];
  low = init( start_pattern[n] );
  for( limit = low; limit <= MAX_MOVE; limit++ ){
    solve_low( limit, 0, 3, low );
  }
  return 0;
}

/* EOF */
