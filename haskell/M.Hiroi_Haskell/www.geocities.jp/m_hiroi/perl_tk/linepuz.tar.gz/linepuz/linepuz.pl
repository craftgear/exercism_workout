#! /usr/bin/perl
#
# linepuz.pl : ラインパズル
#
#              Copyright (C) 2004,2014 Makoto Hiroi
#
use utf8;
use Tk;
use Tk::Dialog;
use File::Basename;

# グローバル変数
@left_panel = ();    # ゴールを表示
@rigth_panel = ();   # パネルを動かす
@panel = (
  [0,1,1,1,1],
  [0,1,1,1,1],
  [0,1,1,1,1],
  [1,1,1,1,1]
);

# ステージ番号
$stage_number = 1;

# ゲーム実行フラグ
$play_flag = 0;

# 円弧図形 id を格納
#  0 2
#  1 3
#  4 は空き場所
@left_arc = ();
@right_arc = ();

# 定数もどき
#
#  A C
#  B D
#
$A = 0;
$B = 1;
$C = 2;
$D = 3;
$S = 4;

#
# データ
# 
@pattern_a = (
  [-1, $A, $B, $A, $B],
  [-1, $C, $A, $B, $D],
  [-1, $A, $C, $D, $B],
  [$S, $C, $D, $C, $D],
);

@pattern_b = (
  [-1, $A, $B, $A, $B],
  [-1, $C, $B, $D, $D],
  [-1, $A, $A, $C, $B],
  [$S, $C, $D, $C, $D],
);

@pattern_c = (
  [-1, $A, $B, $D, $B],
  [-1, $B, $D, $C, $D],
  [-1, $A, $B, $A, $C],
  [$S, $C, $A, $C, $D],
);

@pattern_d = (
  [-1, $A, $B, $A, $B],
  [-1, $C, $D, $C, $D],
  [-1, $A, $B, $A, $B],
  [$S, $C, $D, $C, $D],
);

@pattern_e = (
  [-1, $A, $A, $B, $B],
  [-1, $A, $A, $B, $B],
  [-1, $C, $C, $D, $D],
  [$S, $C, $C, $D, $D],
);

@pattern_f = (
  [-1, $A, $D, $C, $B],
  [-1, $C, $B, $A, $D],
  [-1, $A, $D, $C, $B],
  [$S, $C, $B, $A, $D],
);


@start_pattern = (
  0,
  \@pattern_a,
  \@pattern_b,
  \@pattern_d,
  \@pattern_a,
  \@pattern_b,
  \@pattern_f,
  \@pattern_c,
  \@pattern_e,
  \@pattern_b,
  \@pattern_f,
  \@pattern_c,
  \@pattern_a,
  \@pattern_c,
  \@pattern_e,
  \@pattern_f,
);

@goal_pattern = (
  0,
  \@pattern_b,
  \@pattern_d,
  \@pattern_a,
  \@pattern_e,
  \@pattern_f,
  \@pattern_d,
  \@pattern_f,
  \@pattern_b,
  \@pattern_c,
  \@pattern_a,
  \@pattern_d,
  \@pattern_c,
  \@pattern_e,
  \@pattern_d,
  \@pattern_e,
);

# 最小手数
@min_step = (
  0,
  10, 14, 18, 24, 24,
  26, 26, 28, 30, 30,
  32, 32, 32, 34, 40,
);

# 盤面
@left_board = ();
@right_board = ();

# 盤面の初期化
sub init_board {
  my ($data, $board, $arc_id, $panel_id) = @_;
  my ($x, $y);
  for($x = 0; $x < 4; $x++ ){
    for( $y = 0; $y < 5; $y++ ){
      my $p = $data->[$x][$y];
      $board->[$x][$y] = $p;
      if( $panel[$x][$y] ){
        # パネルを表に出す
        $c0->raise( $panel_id->[$x][$y] );
        # 円弧を出す
        if( $p >= 0 && $p <= 3 ){
          $c0->raise( $arc_id->[$x][$y][$p] );
        }
      }
    }
  }
}

# 終了チェック
sub check_finish {
  my ($x, $y);
  my $goal = $goal_pattern[$stage_number];
  for( $x = 0; $x < 4; $x++ ){
    for( $y = 0; $y < 5; $y++ ){
      return 0 if $right_board[$x][$y] != $goal->[$x][$y];
    }
  }
  return 1;
}


# パネルを押す
sub push_panel {
  my ($obj, $x, $y) = @_;
  my @dx = (1, -1, 0, 0);
  my @dy = (0, 0, 1, -1);
  my $i;
  return unless $play_flag;
  for( $i = 0; $i < 4; $i++ ){
    my $x1 = $x + $dx[$i];
    my $y1 = $y + $dy[$i];
    if( $x1 >= 0 && $x1 < 4 && $y1 >= 0 && $y1 < 5 ){
      if( $right_board[$x1][$y1] == $S ){
        # 移動する
        my $tmp = $right_board[$x][$y];
        $right_board[$x][$y] = $S;
        $right_board[$x1][$y1] = $tmp;
        $c0->lower( $right_arc[$x][$y][$tmp] );
        $c0->raise( $right_arc[$x1][$y1][$tmp] );
        $now_step++;
        last;
      }
    }
  }
  &display_step();
  if( &check_finish() ){
    $dialog->Show();
    $play_flag = 0;
  }
}

# ゲームの開始
sub new_game {
  $now_step = 0;
  $play_flag = 1;
  init_board( $start_pattern[$stage_number], \@right_board, \@right_arc, \@right_panel );
  init_board( $goal_pattern[$stage_number], \@left_board, \@left_arc, \@left_panel );
  &display_step();
}

# ステップ数の表示
sub display_step {
  $output_label = sprintf("Stage %2d : Min Steps %3d : Steps %3d",
                          $stage_number, $min_step[$stage_number], $now_step);
}

# 円弧を描く
sub draw_arc {
  my ($x, $y, $d, $c) = @_;
  my $id_list = [];
  # type 0
  my $x1 = $x * 50 + 14 + $d;
  my $y1 = $y * 50 + 14;
  my $x2 = $x1 + 100 - 8;
  my $y2 = $y1 + 100 - 8;
  my $id =  $c0->create('arc', $x1, $y1, $x2, $y2, -style => 'arc',
                     -start => 94, -extent => 82, -width => 3, -outline => $c );
  $id_list->[0] = $id;
  # type 2
  $x1 -= 50; $x2 -= 50;
  $id =  $c0->create('arc', $x1, $y1, $x2, $y2, -style => 'arc',
                     -start => 4, -extent => 82, -width => 3, -outline => $c );
  $id_list->[2] = $id;
  # type 3
  $y1 -= 50; $y2 -= 50;
  $id =  $c0->create('arc', $x1, $y1, $x2, $y2, -style => 'arc',
                     -start => 274, -extent => 82, -width => 3, -outline => $c );
  $id_list->[3] = $id;
  # type 1
  $x1 += 50; $x2 += 50;
  $id =  $c0->create('arc', $x1, $y1, $x2, $y2, -style => 'arc',
                     -start => 184, -extent => 82, -width => 3, -outline => $c );
  $id_list->[1] = $id;
  foreach $i (@{$id_list}) {
    if( $d > 0 ){
      $c0->bind( $i, "<Button-1>" => [\&push_panel, $x, $y] );
    }
    $c0->lower( $i );
  }
  $id_list;
}

# 次のステージへ
sub next_stage {
  if( ++$stage_number > 15 ){
    $stage_number = 1;
  }
  &new_game();
}

# ヘルプの表示
sub help {
  if( !$help_window or !Exists( $help_window ) ){
    $help_window = MainWindow->new();
    $help_window->title("Help");
    $t0 = $help_window->Scrolled( 'Text', -scrollbars => 'se' )->pack();
    $t0->configure( -font => 'Takaoゴシック 12' );
    # パスを取得
    $dir = &dirname( $0 );
    open(IN, "<:utf8", "$dir/linepuz.txt");
    while( <IN> ){
      $t0->insert( 'end', $_ );
    }
    close( IN );
    $t0->configure( -state => 'disable' );
  }
  $help_window->focusForce();
}

# ***** メインウィンドウの設定 *****
$top = MainWindow->new();
$top->optionAdd( '*font' => 'Takaoゴシック 10' );

# メニューの設定
$m = $top->Menu( -type => 'menubar' );
$top->configure( -menu => $m );

$m1 = $m->cascade(-label => 'Games', -under => 0, -tearoff => 0);
$m2 = $m->command(-label => 'Next',  -under => 0, -command => \&next_stage);
$m3 = $m->command(-label => 'Retry', -under => 0, -command => \&new_game);
$m4 = $m->command(-label => 'Help',  -under => 0, -command => \&help);

$m1->radiobutton(-label => 'Stage 1', -variable => \$stage_number, -value => 1, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 2', -variable => \$stage_number, -value => 2, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 3', -variable => \$stage_number, -value => 3, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 4', -variable => \$stage_number, -value => 4, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 5', -variable => \$stage_number, -value => 5, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 6', -variable => \$stage_number, -value => 6, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 7', -variable => \$stage_number, -value => 7, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 8', -variable => \$stage_number, -value => 8, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 9', -variable => \$stage_number, -value => 9, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 10', -variable => \$stage_number, -value => 10, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 11', -variable => \$stage_number, -value => 11, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 12', -variable => \$stage_number, -value => 12, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 13', -variable => \$stage_number, -value => 13, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 14', -variable => \$stage_number, -value => 14, -command => \&new_game);
$m1->radiobutton(-label => 'Stage 15', -variable => \$stage_number, -value => 15, -command => \&new_game);
$m1->separator;
$m1->command(-label => 'Exit', -under => 0, -command => \&exit );

# ステップ表示用ラベルの設定
$l0 = $top->Label( -textvariable => \$output_label, -font => 'Takaoゴシック 14', -bg => '#00C000' )->pack( -fill => 'x' );



# キャンバスウィジェットの設定
$c0 = $top->Canvas( -width => 470, -height => 270, -bg => '#00A000' );
$c0->create('rectangle', 235, 2, 470, 270, -fill => '#00C000' );

# 図形の初期化
for( $x = 0; $x < 4; $x++ ){
  $x1 = $x * 50 + 11;
  $x2 = $x1 + 250;
  $left_panel[$x] = [];
  $right_panel[$x] = [];
  $left_board[$x] = [];
  $right_board[$x] = [];
  for( $y = 0; $y < 5; $y++ ){
    if( $panel[$x][$y] ){
      $y1 = $y * 50 + 11;
      $id = $c0->create('rectangle', $x1, $y1, $x1 + 48, $y1 + 48, -fill => 'white' );
      $left_panel[$x][$y] = $id;
      $id = $c0->create('rectangle', $x2, $y1, $x2 + 48, $y1 + 48, -fill => 'white' );
      $c0->bind( $id, "<Button-1>" => [\&push_panel, $x, $y] );
      $right_panel[$x][$y] = $id;
    }
  }
}

# 円を描く
for( $x = 0; $x < 4; $x++ ){
  $left_arc[$x] = [];
  $right_arc[$x] = [];
  for( $y = 0; $y < 5; $y++ ){
    if( $panel[$x][$y] ){
      $left_arc[$x][$y] = &draw_arc( $x, $y, 0, 'blue' );
      $right_arc[$x][$y] = &draw_arc( $x, $y, 250, 'red' );
    }
  }
}

$c0->pack();

# ダイアログ
$dialog = $top->Dialog( -text => 'Congratulation!' );

# メインウィンドウの設定
$top->title("Line Puzzle");
$top->focus();
&new_game();

# メインループ
MainLoop();

# end of file
